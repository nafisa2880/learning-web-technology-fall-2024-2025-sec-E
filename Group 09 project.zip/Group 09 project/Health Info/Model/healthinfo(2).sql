-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 17, 2025 at 07:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--
use healthinfo;

drop table appointments;
CREATE TABLE appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY, -- Unique ID for each appointment
    user_id INT NOT NULL,                          -- Foreign key referencing users
    patient_name VARCHAR(100) NOT NULL,           -- Patient's full name
    doctor VARCHAR(100) NOT NULL,                 -- Doctor's name
    appointment_date DATE NOT NULL,               -- Appointment date
    appointment_time TIME NOT NULL,               -- Appointment time
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Creation timestamp
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);



--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`user_id`, `appointment_id`, `patient_name`, `doctor`, `appointment_date`, `appointment_time`) VALUES
(11, 6, 'karim reza roniss', 'Dr. Ahsan Habib', '2025-01-22', '10:00:00'),
(10, 36, 'roni islam', 'Dr. Farhan Rahman', '2025-01-24', '12:00:00'),
(13, 45, 'nusrat jannat', 'Dr. Shafiq Rahim', '2025-02-27', '12:00:00');

-- --------------------------------------------------------
select * from appointments;
--
-- Table structure for table `availability`
--

CREATE TABLE `availability` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `doctor_name` varchar(255) NOT NULL,
  `day` varchar(50) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `availability`
--

INSERT INTO `availability` (`id`, `doctor_id`, `doctor_name`, `day`, `start_time`, `end_time`) VALUES
(1, 1, 'Dr. Tasfi', 'Tuesday', '14:24:00', '15:24:00');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `specialty` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `name`, `specialty`) VALUES
(1, 'Dr. Tasfi', 'Cardiology'),
(2, 'Dr. Tani', 'Dermatology');

-- --------------------------------------------------------

--
-- Table structure for table `favourite_doctors`
--

CREATE TABLE `favourite_doctors` (
  `favourite_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favourite_doctors`
--

INSERT INTO `favourite_doctors` (`favourite_id`, `patient_id`, `doctor_id`, `added_at`) VALUES
(1, 42, 32, '2025-01-05 15:57:58'),
(2, 42, 31, '2025-01-05 16:01:36'),
(20, 13, 32, '2025-01-16 15:33:17'),
(21, 13, 30, '2025-01-16 16:15:30'),
(22, 13, 20, '2025-01-16 16:15:41'),
(23, 13, 19, '2025-01-16 16:15:50'),
(24, 13, 24, '2025-01-16 16:15:54'),
(25, 13, 23, '2025-01-16 16:15:58'),
(26, 13, 21, '2025-01-16 16:16:02'),
(31, 13, 25, '2025-01-17 04:08:57'),
(32, 13, 55, '2025-01-17 05:14:32');

-- --------------------------------------------------------

--
-- Table structure for table `medical_files`
--

CREATE TABLE `medical_files` (
  `file_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `uploader_role` enum('Patient','Doctor') NOT NULL,
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `file_type` varchar(200) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medical_files`
--

INSERT INTO `medical_files` (`file_id`, `user_id`, `uploader_role`, `file_name`, `file_path`, `file_type`, `upload_date`) VALUES
(1, 13, 'Patient', 'blood test report', '', 'pdf', '2025-01-05 13:49:51'),
(3, 13, 'Patient', 'AI-Lecture-06[CSP].pptx.pdf', 'uploads/medical_files/677a8fa69cb50_AI-Lecture-06[CSP].pptx.pdf', 'pdf', '2025-01-05 13:56:54'),
(4, 42, 'Patient', '677a8fa69cb50_AI-Lecture-06[CSP].pptx.pdf', 'uploads/medical_files/677a9e295f5a7_677a8fa69cb50_AI-Lecture-06[CSP].pptx.pdf', 'pdf', '2025-01-05 14:58:49'),
(5, 13, 'Patient', '677a8fa69cb50_AI-Lecture-06[CSP].pptx.pdf', 'uploads/medical_files/677b588f0341a_677a8fa69cb50_AI-Lecture-06[CSP].pptx.pdf', 'pdf', '2025-01-06 04:14:07'),
(6, 13, 'Patient', 'php.docx', 'uploads/medical_files/6786aa8f00684_php.docx', 'docx', '2025-01-14 18:18:55'),
(7, 13, 'Patient', 'php.docx', 'uploads/medical_files/6786aad92bfa7_php.docx', 'docx', '2025-01-14 18:20:09'),
(8, 13, 'Patient', 'Lecture_04_WT_Theory(1).pptx', 'uploads/medical_files/678768a3ca9ae_Lecture_04_WT_Theory(1).pptx', 'pptx', '2025-01-15 07:49:55'),
(9, 13, 'Patient', 'output(3).png', 'uploads/medical_files/67893a4878dfa_output(3).png', 'png', '2025-01-16 16:56:40'),
(10, 13, 'Patient', '2. VLAN and VTP.pdf', 'uploads/medical_files/67893af261eca_2. VLAN and VTP.pdf', 'pdf', '2025-01-16 16:59:30'),
(11, 13, 'Patient', 'HARD DISK ERROR SMALL PHOTO.jpg', 'uploads/medical_files/6789d97a63e67_HARD DISK ERROR SMALL PHOTO.jpg', 'jpg', '2025-01-17 04:15:54'),
(12, 13, 'Patient', 'RQ1_Digital_Entrepreneurship_Process.png', 'uploads/medical_files/6789e748d8141_RQ1_Digital_Entrepreneurship_Process.png', 'png', '2025-01-17 05:14:48');

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

CREATE TABLE `prescriptions` (
  `id` int(11) NOT NULL,
  `doctor_name` varchar(100) NOT NULL,
  `patient_name` varchar(100) NOT NULL,
  `medicine` text NOT NULL,
  `dosage` text NOT NULL,
  `additional_notes` text DEFAULT NULL,
  `date_issued` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prescriptions`
--

INSERT INTO `prescriptions` (`id`, `doctor_name`, `patient_name`, `medicine`, `dosage`, `additional_notes`, `date_issued`) VALUES
(1, 'tasfi islam', 'moon', 'napa', '5 dose per day', 'dont overthink', '2025-01-18');

-- --------------------------------------------------------

--
-- Table structure for table `symptoms_conditions`
--

CREATE TABLE `symptoms_conditions` (
  `id` int(11) NOT NULL,
  `symptom_name` varchar(100) NOT NULL,
  `condition_name` varchar(100) NOT NULL,
  `advice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `symptoms_conditions`
--

INSERT INTO `symptoms_conditions` (`id`, `symptom_name`, `condition_name`, `advice`) VALUES
(1, 'Fever', 'Flu', 'Rest, stay hydrated, and consult a doctor if symptoms persist.'),
(2, 'Headache', 'Migraine', 'Avoid bright lights, take prescribed medication, and relax.'),
(3, 'Cough', 'Cold', 'Drink warm fluids, rest, and use over-the-counter remedies.'),
(4, 'Sore Throat', 'Flu', 'Gargle with warm salt water, stay hydrated, and avoid cold drinks.'),
(5, 'Fatigue', 'Anemia', 'Increase iron intake, consult a doctor for further tests.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `role` enum('Patient','Doctor','Admin') NOT NULL,
  `contact_number` varchar(250) NOT NULL,
  `address` text DEFAULT NULL,
  `specialty` varchar(250) DEFAULT NULL,
  `experience_years` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `username`, `password`, `dob`, `gender`, `role`, `contact_number`, `address`, `specialty`, `experience_years`, `created_at`) VALUES
(10, 'roni', 'islam touhid', 'roni774', '123456', '2024-10-03', 'Male', 'Patient', '01705479538', 'House no : 167/A, bottola bhumi office, khilkhet, dhaka1229', NULL, NULL, '2025-01-05 11:02:33'),
(11, 'wafi', 'zannat', 'admin1', '123456', '2012-07-01', 'Male', 'Admin', '01234562131', 'House no : 167/A, bottola bhumi office, khilkhet, dhaka1229', NULL, NULL, '2025-01-05 11:02:33'),
(13, 'nusrat', 'jannat', 'wifi123', '123456', '2000-10-12', 'Female', 'Patient', '01705479538', 'House no : 167/A, bottola bhumi office, khilkhet, dhaka1229', NULL, NULL, '2025-01-05 11:02:33'),
(18, 'Dr. Ahsan', 'Habib', 'drahsan', '123456', '1980-01-01', 'Male', 'Doctor', '1234567890', 'Kuratoli, Dhaka', 'Cardiologist', 12, '2025-01-05 14:20:48'),
(19, 'Dr. Nusrat', 'Jahan', 'drnusrat', '123456', '1985-02-10', 'Female', 'Doctor', '1234567891', 'Banani, Dhaka', 'Dermatologist', 8, '2025-01-05 14:20:48'),
(20, 'Dr. Farhan', 'Rahman', 'drfarhan', '123456', '1978-03-20', 'Male', 'Doctor', '1234567892', 'Dhanmondi, Dhaka', 'Orthopedic', 12, '2025-01-05 14:20:48'),
(21, 'Dr. Ayesha', 'Khan', 'drayesha', '123456', '1987-04-15', 'Female', 'Doctor', '1234567893', 'Uttara, Dhaka', 'Gynecologist', 7, '2025-01-05 14:20:48'),
(22, 'Dr. Imran', 'Ahmed', 'drimran', '123456', '1975-05-05', 'Male', 'Doctor', '1234567894', 'Mirpur, Dhaka', 'Pediatrician', 15, '2025-01-05 14:20:48'),
(23, 'Dr. Shirin', 'Akter', 'drshirin', '123456', '1982-06-25', 'Female', 'Doctor', '1234567895', 'Gulshan, Dhaka', 'Neurologist', 9, '2025-01-05 14:20:48'),
(24, 'Dr. Mahmud', 'Hassan', 'drmahmud', '123456', '1979-07-12', 'Male', 'Doctor', '1234567896', 'Bashundhara, Dhaka', 'Oncologist', 11, '2025-01-05 14:20:48'),
(25, 'Dr. Tanvir', 'Rashid', 'drtanvir', '123456', '1983-08-08', 'Male', 'Doctor', '1234567897', 'Khilgaon, Dhaka', 'Endocrinologist', 10, '2025-01-05 14:20:48'),
(26, 'Dr. Sharmin', 'Sultana', 'drsharmin', '123456', '1981-09-18', 'Female', 'Doctor', '1234567898', 'Baridhara, Dhaka', 'Psychiatrist', 10, '2025-01-05 14:20:48'),
(27, 'Dr. Ashraf', 'Ali', 'drashraf', '123456', '1980-10-05', 'Male', 'Doctor', '1234567899', 'Mohammadpur, Dhaka', 'Ophthalmologist', 12, '2025-01-05 14:20:48'),
(28, 'Dr. Farzana', 'Begum', 'drfarzana', '123456', '1984-11-11', 'Female', 'Doctor', '1234567890', 'Tejgaon, Dhaka', 'Rheumatologist', 8, '2025-01-05 14:20:48'),
(29, 'Dr. Karim', 'Haque', 'drkarim', '123456', '1976-12-22', 'Male', 'Doctor', '1234567891', 'Banasree, Dhaka', 'Radiologist', 15, '2025-01-05 14:20:48'),
(30, 'Dr. Rubaiya', 'Chowdhury', 'drrubaiya', '123456', '1985-01-13', 'Female', 'Doctor', '1234567892', 'Shantinagar, Dhaka', 'Pulmonologist', 7, '2025-01-05 14:20:48'),
(31, 'Dr. Shafiq', 'Rahim', 'drshafiq', '123456', '1977-02-14', 'Male', 'Doctor', '1234567893', 'Agargaon, Dhaka', 'Nephrologist', 14, '2025-01-05 14:20:48'),
(32, 'Dr. Nusrat', 'Rahman', 'drnusratrahman', '123456', '1986-03-23', 'Female', 'Doctor', '1234567894', 'Malibagh, Dhaka', 'Gastroenterologist', 6, '2025-01-05 14:20:48'),
(33, 'Rakib', 'Hossain', 'rakibhossain1', '123456', '1990-01-15', 'Male', 'Patient', '01712345678', 'Dhanmondi, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
(34, 'Shapla', 'Begum', 'shaplabegum2', '123456', '1992-03-10', 'Female', 'Patient', '01812345678', 'Mirpur, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
(35, 'Sajib', 'Ahmed', 'sajibahmed3', '123456', '1985-07-20', 'Male', 'Patient', '01912345678', 'Gulshan, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
(36, 'Farzana', 'Aktar', 'farzanaaktar4', '123456', '1995-11-25', 'Female', 'Patient', '01798765432', 'Banani, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
(37, 'Tareq', 'Islam', 'tareqislam5', '123456', '1987-06-30', 'Male', 'Patient', '01987654321', 'Uttara, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
(38, 'Rima', 'Sultana', 'rimasultana6', '123456', '1991-12-05', 'Female', 'Patient', '01823456789', 'Motijheel, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
(39, 'Ashik', 'Rahman', 'ashikrahman7', '123456', '1993-04-18', 'Male', 'Patient', '01734567890', 'Bashundhara, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
(40, 'Nasima', 'Khatun', 'nasimakhatun8', '123456', '1996-08-10', 'Female', 'Patient', '01845678901', 'Jatrabari, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
(41, 'Imran', 'Hasan', 'imranhasan9', '123456', '1994-02-22', 'Male', 'Patient', '01956789012', 'Shantinagar, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
(42, 'Sharmin', 'Jahan', 'sharminjahan10', '123456', '1992-09-15', 'Female', 'Patient', '01767890123', 'Khilgaon, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
(43, 'bibi', 'jahan', 'bbb123', '$2y$10$T2NfRAz.n4FvMwV1FVPzKOTiUhrf.RhiYACaNP.OY1n', '2023-12-12', 'Female', 'Patient', '', NULL, NULL, NULL, '2025-01-06 03:37:35'),
(44, 'munni', 'islam', 'munni123', '$2y$10$TJy/WpY5f3i9HA/rbBtU8O8N0q5tsHd38ExIeLrWLQV', '2025-01-24', 'Female', 'Patient', '', NULL, NULL, NULL, '2025-01-06 05:08:58'),
(45, 'nusrat', 'muntaha', 'muntaha1234', '$2y$10$IFYTLMn8J1MtVuDVkyPxIeXtXIXvNh6ekCUq256/ePi', '2023-06-12', 'Female', 'Patient', '', NULL, NULL, NULL, '2025-01-11 11:04:48'),
(46, 'munnia', 'akter', 'munni12375675', '$2y$10$x6TlwSesSrgD90UiehVwGuQFETj3EXgqiO/l3rG7oG2', '2025-01-03', 'Female', 'Patient', '', NULL, NULL, NULL, '2025-01-11 11:48:16'),
(47, 'munnia', 'akter', 'munni12375675111', '$2y$10$xop4GAbqpmSTEjdUoGW5XeSDmd88GtHrXIll0WwTuVG', '2025-01-03', 'Female', 'Patient', '', NULL, NULL, NULL, '2025-01-11 11:52:52'),
(48, 'munnia', 'akter', 'munni12375675111111', '$2y$10$7reQ42cV4WeOSCGD1M8s6.edNQcQm8VRO8ZqhmdTCP8', '2025-01-03', 'Female', 'Patient', '', NULL, NULL, NULL, '2025-01-11 11:54:55'),
(49, 'munnia', 'akter', 'munni123756751112344', '$2y$10$aP/NwZk.6EDHr198s5Nt2eGoCopi2FlZyM8yD07JOJK', '2025-01-03', 'Female', 'Patient', '', NULL, NULL, NULL, '2025-01-11 11:59:20'),
(50, 'munnia', 'akter', 'munni123756751112334', '$2y$10$52CVjXLOZsWTqPFXLlFoVeMfpmRaJJ4xD.5wI2LNdBJ', '2025-01-03', 'Female', 'Patient', '', NULL, NULL, NULL, '2025-01-11 12:01:40'),
(51, 'munnia', 'akter', 'munni123776751112334', '$2y$10$UEudF3dFEpCFgNa.iGRppuy5TbEOE2ikrL.P2.wrsmU', '2025-01-03', 'Female', 'Patient', '', NULL, NULL, NULL, '2025-01-11 12:02:21'),
(52, 'nazma', 'akter', 'nazma123', '$2y$10$eus6wpd1U9QxUzNO5S3kx.LMIccj0ReHIB6BQYL4dl0', '2024-05-07', 'Female', 'Patient', '', NULL, NULL, NULL, '2025-01-11 14:27:18'),
(53, 'tajul', 'islam', 'tajul22244', '$2y$10$Xh01Iv39xRgL7xrFWK4zUuHfmeC.DxKYUpWTj4wl1KX', '1977-01-12', 'Male', 'Patient', '', '', NULL, NULL, '2025-01-11 14:45:46'),
(54, 'nazmul', 'Islam', 'raju123', '$2y$10$2eqy0k5fU9OMFWgwhUOgZuttj5IDfhfYi2tcFx6USQf', '1992-10-31', 'Male', 'Doctor', '', '', NULL, NULL, '2025-01-13 12:46:56'),
(55, 'nazmul', 'Islam', 'raju1234', '$2y$10$.LLh1O/e3sYBpxGLhktj8e4JUA2VXUlyuRtvbPccZNJ', '1992-10-31', 'Male', 'Doctor', '', '', NULL, NULL, '2025-01-13 12:49:01'),
(56, 'tajul', 'islam', 'tajul123', '$2y$10$fq5SKVsVlHOf9LbHoi5eLueDgesjEHqQu2rKyWSFUFp', '2023-03-21', 'Male', 'Patient', '', '', NULL, NULL, '2025-01-17 05:05:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `availability`
--
ALTER TABLE `availability`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favourite_doctors`
--
ALTER TABLE `favourite_doctors`
  ADD PRIMARY KEY (`favourite_id`);

--
-- Indexes for table `medical_files`
--
ALTER TABLE `medical_files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `fk_user_medical_files` (`user_id`);

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `symptoms_conditions`
--
ALTER TABLE `symptoms_conditions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `availability`
--
ALTER TABLE `availability`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `favourite_doctors`
--
ALTER TABLE `favourite_doctors`
  MODIFY `favourite_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `medical_files`
--
ALTER TABLE `medical_files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `symptoms_conditions`
--
ALTER TABLE `symptoms_conditions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `availability`
--
ALTER TABLE `availability`
  ADD CONSTRAINT `availability_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`);

--
-- Constraints for table `medical_files`
--
ALTER TABLE `medical_files`
  ADD CONSTRAINT `fk_user_medical_files` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

CREATE TABLE medical_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    condition VARCHAR(255) NOT NULL,
    diagnosis_date DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);


CREATE TABLE appointments1 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    doctor_name VARCHAR(100) NOT NULL,
    appointment_date DATE NOT NULL,
    status ENUM('upcoming', 'completed', 'cancelled') DEFAULT 'upcoming',
    notes TEXT

);

CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    doctor_name VARCHAR(255) NOT NULL,
    date DATE NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);