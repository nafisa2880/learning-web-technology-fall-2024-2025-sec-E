CREATE DATABASE healthinfo;
use healthinfo;
CREATE DATABASE healthinfo;
use healthinfo;
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY, -- Unique ID for each user
    first_name VARCHAR(50) NOT NULL,        -- First name of the user
    last_name VARCHAR(50) NOT NULL,         -- Last name of the user
    username VARCHAR(50) NOT NULL UNIQUE,   -- Unique username
    email VARCHAR(255) NOT NULL UNIQUE,     -- Unique email
    gender ENUM('male', 'female', 'other') NOT NULL, -- Gender options
    password VARCHAR(255) NOT NULL,         -- Hashed password
    role ENUM('patient', 'doctor', 'admin') NOT NULL, -- User role
    contact_number VARCHAR(250) NOT NULL,   -- Contact number
    address TEXT DEFAULT NULL,              -- Address (optional)
    specialty VARCHAR(250) DEFAULT NULL,    -- Specialty (for doctors)
    experience_years INT(11) DEFAULT NULL,  -- Experience years (for doctors)
    created_at TIMESTAMP NOT NULL DEFAULT current_timestamp() -- Creation timestamp
);
ALTER TABLE users
ADD COLUMN dob DATE NOT NULL AFTER email;

ALTER TABLE users
ADD COLUMN `contact_number` VARCHAR(250) NOT NULL,
ADD COLUMN `address` TEXT DEFAULT NULL,
ADD COLUMN `specialty` VARCHAR(250) DEFAULT NULL,
ADD COLUMN `experience_years` INT(11) DEFAULT NULL,
ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT current_timestamp();

ALTER TABLE users
ADD COLUMN `user_id` INT AUTO_INCREMENT PRIMARY KEY;
select * from users;
drop table users;
INSERT INTO users 
    (user_id, first_name, last_name, username, email, gender, password, role, contact_number, address, specialty, experience_years, created_at) 
VALUES
    (10, 'roni', 'islam touhid', 'roni774', 'roni774@example.com', 'male', '123456', 'patient', '01705479538', 'House no: 167/A, bottola bhumi office, khilkhet, Dhaka 1229', NULL, NULL, '2025-01-05 11:02:33'),
    (11, 'wafi', 'zannat', 'admin1', 'admin1@example.com', 'male', '123456', 'admin', '01234562131', 'House no: 167/A, bottola bhumi office, khilkhet, Dhaka 1229', NULL, NULL, '2025-01-05 11:02:33'),
    (13, 'nusrat', 'jannat', 'wifi123', 'wifi123@example.com', 'female', '123456', 'patient', '01705479538', 'House no: 167/A, bottola bhumi office, khilkhet, Dhaka 1229', NULL, NULL, '2025-01-05 11:02:33'),
    (18, 'Dr. Ahsan', 'Habib', 'drahsan', 'drahsan@example.com', 'male', '123456', 'doctor', '1234567890', 'Kuratoli, Dhaka', 'Cardiologist', 12, '2025-01-05 14:20:48'),
    (19, 'Dr. Nusrat', 'Jahan', 'drnusrat', 'drnusrat@example.com', 'female', '123456', 'doctor', '1234567891', 'Banani, Dhaka', 'Dermatologist', 8, '2025-01-05 14:20:48'),
    (20, 'Dr. Farhan', 'Rahman', 'drfarhan', 'drfarhan@example.com', 'male', '123456', 'doctor', '1234567892', 'Dhanmondi, Dhaka', 'Orthopedic', 12, '2025-01-05 14:20:48'),
    (21, 'Dr. Ayesha', 'Khan', 'drayesha', 'drayesha@example.com', 'female', '123456', 'doctor', '1234567893', 'Uttara, Dhaka', 'Gynecologist', 7, '2025-01-05 14:20:48'),
    (22, 'Dr. Imran', 'Ahmed', 'drimran', 'drimran@example.com', 'male', '123456', 'doctor', '1234567894', 'Mirpur, Dhaka', 'Pediatrician', 15, '2025-01-05 14:20:48'),
    (23, 'Dr. Shirin', 'Akter', 'drshirin', 'drshirin@example.com', 'female', '123456', 'doctor', '1234567895', 'Gulshan, Dhaka', 'Neurologist', 9, '2025-01-05 14:20:48'),
    (24, 'Dr. Mahmud', 'Hassan', 'drmahmud', 'drmahmud@example.com', 'male', '123456', 'doctor', '1234567896', 'Bashundhara, Dhaka', 'Oncologist', 11, '2025-01-05 14:20:48'),
    (25, 'Dr. Tanvir', 'Rashid', 'drtanvir', 'drtanvir@example.com', 'male', '123456', 'doctor', '1234567897', 'Khilgaon, Dhaka', 'Endocrinologist', 10, '2025-01-05 14:20:48'),
    (26, 'Dr. Sharmin', 'Sultana', 'drsharmin', 'drsharmin@example.com', 'female', '123456', 'doctor', '1234567898', 'Baridhara, Dhaka', 'Psychiatrist', 10, '2025-01-05 14:20:48'),
    (27, 'Dr. Ashraf', 'Ali', 'drashraf', 'drashraf@example.com', 'male', '123456', 'doctor', '1234567899', 'Mohammadpur, Dhaka', 'Ophthalmologist', 12, '2025-01-05 14:20:48'),
    (28, 'Dr. Farzana', 'Begum', 'drfarzana', 'drfarzana@example.com', 'female', '123456', 'doctor', '1234567890', 'Tejgaon, Dhaka', 'Rheumatologist', 8, '2025-01-05 14:20:48'),
    (29, 'Dr. Karim', 'Haque', 'drkarim', 'drkarim@example.com', 'male', '123456', 'doctor', '1234567891', 'Banasree, Dhaka', 'Radiologist', 15, '2025-01-05 14:20:48'),
    (30, 'Dr. Rubaiya', 'Chowdhury', 'drrubaiya', 'drrubaiya@example.com', 'female', '123456', 'doctor', '1234567892', 'Shantinagar, Dhaka', 'Pulmonologist', 7, '2025-01-05 14:20:48'),
    (31, 'Dr. Shafiq', 'Rahim', 'drshafiq', 'drshafiq@example.com', 'male', '123456', 'doctor', '1234567893', 'Agargaon, Dhaka', 'Nephrologist', 14, '2025-01-05 14:20:48'),
    (32, 'Dr. Nusrat', 'Rahman', 'drnusratrahman', 'drnusratrahman@example.com', 'female', '123456', 'doctor', '1234567894', 'Malibagh, Dhaka', 'Gastroenterologist', 6, '2025-01-05 14:20:48'),
    (33, 'Rakib', 'Hossain', 'rakibhossain1', 'rakibhossain1@example.com', 'male', '123456', 'patient', '01712345678', 'Dhanmondi, Dhaka', NULL, NULL, '2025-01-05 14:55:43'),
    (34, 'Shapla', 'Begum', 'shaplabegum2', 'shaplabegum2@example.com', 'female', '123456', 'patient', '01812345678', 'Mirpur, Dhaka', NULL, NULL, '2025-01-05 14:55:43');

CREATE TABLE HealthTips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT NOT NULL
);

INSERT INTO HealthTips (title, category, description) VALUES
    ('Exercise Regularly', 'Fitness', 'Engage in at least 30 minutes of moderate exercise daily to maintain physical fitness.'),
    ('Eat More Vegetables', 'Nutrition', 'Include a variety of colorful vegetables in your diet to ensure balanced nutrition.'),
    ('Practice Meditation', 'Mental Health', 'Spend 10-15 minutes daily meditating to reduce stress and improve mental clarity.'),
    ('Stay Hydrated', 'Nutrition', 'Drink at least 8 glasses of water daily to keep your body well-hydrated.'),
    ('Stretch Daily', 'Fitness', 'Incorporate stretching exercises to improve flexibility and reduce muscle tension.'),
    ('Limit Screen Time', 'Mental Health', 'Reduce screen time, especially before bed, to improve sleep quality.'),
    ('Avoid Processed Foods', 'Nutrition', 'Choose whole and fresh foods over processed ones for better health.'),
    ('Strength Training', 'Fitness', 'Add strength training to your routine twice a week to build muscle and support bone health.');
INSERT INTO HealthTips (title, category, description) VALUES
('Stay Hydrated','Nutrition', 'Drink at least 8-10 glasses of water daily to stay hydrated and maintain overall health.'),
('Regular Exercise', 'Fitness', 'Engage in at least 30 minutes of moderate exercise five days a week to improve physical fitness.'),
('Meditation for Stress Relief','Mental Health', 'Practice 10 minutes of meditation daily to reduce stress and improve mental clarity.' ),
('Healthy Breakfast','Nutrition', 'Start your day with a nutritious breakfast that includes protein, whole grains, and fresh fruits.' ),
('Adequate Sleep','Nutrition', 'Aim for 7-8 hours of quality sleep every night to rejuvenate your body and mind.'),
('Take Breaks from Screens', 'Lifestyle','Follow the 20-20-20 rule: every 20 minutes, look at something 20 feet away for 20 seconds.'),
('Boost Immunity','Eye Health', 'Include foods rich in vitamin C, zinc, and antioxidants in your diet to enhance immunity.'),
('Stretching Exercises','Fitness', 'Incorporate stretching into your routine to improve flexibility and prevent muscle stiffness.');


CREATE TABLE faq (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question VARCHAR(255) NOT NULL,
    answer TEXT NOT NULL
);

INSERT INTO faq (question, answer) VALUES
("What is the recommended amount of water to drink daily?", "It's recommended to drink at least 8-10 glasses (2-2.5 liters) of water per day."),
("How much sleep is necessary for a healthy adult?", "Adults should aim for 7-9 hours of quality sleep each night."),
("What are the benefits of regular exercise?", "Regular exercise helps maintain a healthy weight, improves mood, boosts energy, and prevents chronic diseases."),
("How can I reduce stress in my daily life?", "Practice relaxation techniques like deep breathing, meditation, and yoga. Stay organized and make time for hobbies."),
("What are the early signs of dehydration?", "Common signs include dry mouth, fatigue, dizziness, and dark-colored urine."),
("What should a balanced diet include?", "A balanced diet includes fruits, vegetables, whole grains, lean protein, and healthy fats."),
("How often should I visit the doctor for a check-up?", "It's advisable to have an annual health check-up, even if you're feeling well."),
("What vaccines should adults take?", "Adults should take vaccines like the flu shot annually, and others like tetanus and pneumonia as recommended by their doctor."),
("What is the normal range for blood pressure?", "A normal blood pressure reading is around 120/80 mmHg."),
("How can I boost my immune system?", "Eat a healthy diet, stay physically active, get enough sleep, and reduce stress.");

select * from faq;
show databases;
SELECT * FROM HealthTips;
CREATE TABLE reminders (
    id INT AUTO_INCREMENT PRIMARY KEY,          
             
    title VARCHAR(255) NOT NULL,             
    description TEXT NOT NULL,                 
    date DATE NOT NULL,                          
    time TIME NOT NULL,                       
    advice TEXT DEFAULT NULL              
  );
alter table reminders add column  patient_name VARCHAR(255) NOT NULL; 

CREATE TABLE bmiEntries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    weight DECIMAL(5, 2) NOT NULL, 
    height DECIMAL(5, 2) NOT NULL,
    bmi DECIMAL(5, 2) NOT NULL,    
    category VARCHAR(50) NOT NULL
   );
   
   CREATE TABLE bmiAdvice (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(50) UNIQUE NOT NULL, 
    advice TEXT NOT NULL
);

INSERT INTO bmiAdvice (category, advice) VALUES
('Underweight', 'Consider increasing your caloric intake with healthy foods. Include nutrient-rich meals in your diet.'),
('Normal weight', 'Maintain your current lifestyle and continue regular physical activity.'),
('Overweight', 'Engage in regular exercise and focus on a balanced diet with reduced calorie intake.'),
('Obese', 'Consult a healthcare provider for a weight loss plan. Adopt a healthy diet and increase physical activity.');

CREATE TABLE dietPlans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    age_group VARCHAR(20) NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    activity_level ENUM('Low', 'Moderate', 'High') NOT NULL,
    goal TEXT NOT NULL,
    diet_plan TEXT NOT NULL
);
INSERT INTO dietPlans (age_group, gender, activity_level, goal, diet_plan) 
VALUES 
('18-25', 'Male', 'High', 'Muscle Gain', 'High protein diet with lean meats, eggs, and supplements'),
('26-30', 'Female', 'Moderate', 'Weight Loss', 'Low carb diet with vegetables, chicken, and healthy fats'),
('31-40', 'Other', 'Low', 'Maintain Health', 'Balanced diet with whole grains, fruits, and moderate proteins');
