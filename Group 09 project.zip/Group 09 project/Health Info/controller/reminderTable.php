<?php
include_once 'db.php';
session_start();

if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'doctor' && $_SESSION['role'] != 'admin')) {
    echo "Unauthorized access.";
    exit;
}

$role = $_SESSION['role'];

$sql = "SELECT * FROM reminders";
$result = $conn->query($sql);

echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Medication Reminders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        h1 {
            color: #003366;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #003366;
            color: #fff;
        }
        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        table tr:hover {
            background-color: #eaf4fc;
        }
        .actions a {
            color: #00509e;
            text-decoration: none;
            font-weight: bold;
        }
        .actions a:hover {
            text-decoration: underline;
            color: #003366;
        }
        a {
            text-decoration: none;
            color: #00509e;
        }
        a:hover {
            text-decoration: underline;
            color: #003366;
        }
    </style>
</head>
<body>
    <h1>Medication Reminders</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Patient Name</th>
            <th>Title</th>
            <th>Description</th>
            <th>Date</th>
            <th>Time</th>
            <th>Advice</th>
            <th>Actions</th>
        </tr>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['patient_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['title']) . "</td>";
        echo "<td>" . htmlspecialchars($row['description']) . "</td>";
        echo "<td>" . htmlspecialchars($row['date']) . "</td>";
        echo "<td>" . htmlspecialchars($row['time']) . "</td>";
        echo "<td>" . htmlspecialchars($row['advice'] ?? "None") . "</td>";
        echo "<td class='actions'>";
        if ($role == 'doctor' && empty($row['advice'])) {
            echo "<a href='../control/addAdvice.php?id=" . $row['id'] . "'>Add Advice</a>";
        }
        if ($role == 'admin') {
            echo "<a href='../control/deleteReminder.php?id=" . $row['id'] . "'>Delete</a>";
        }
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='8'>No reminders found.</td></tr>";
}

echo "</table>";
echo "<br>";
echo "<a href='../view/index.html' style='display: inline-block; margin: 20px 0; font-size: 16px; color: #003366;'>Back to Home Page</a>";
echo "</body></html>";

$conn->close();
?>
