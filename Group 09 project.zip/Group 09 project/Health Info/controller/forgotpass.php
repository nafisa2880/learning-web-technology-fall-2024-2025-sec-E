<?php
include_once 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $email = trim($_POST['email']);

    // Validate input
    if (empty($email)) {
        die("Error: Email is required.");
    }

    // Sanitize the email to prevent SQL injection
    $email = mysqli_real_escape_string($conn, $email);

    // Query to check if the email exists
    $sql = "SELECT user_id FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows === 1) {
        // Email found
        $_SESSION['reset_email'] = $email;
        header("Location: ../view/resetpass.html");
        exit;
    } else {
        // Email not found
        echo "Error: Email not registered.";
    }
} else {
    echo "Invalid request.";
}

// Close the connection
$conn->close();
?>
