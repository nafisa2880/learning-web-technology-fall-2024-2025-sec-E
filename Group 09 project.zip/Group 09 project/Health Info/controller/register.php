<?php
include_once 'db.php'; // Ensure the correct path to db.php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize form data manually
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash the password
    $dob = trim($_POST['dob']);
    $gender = trim($_POST['gender']);
    $role = trim($_POST['role']);
    $contact_number = trim($_POST['contact_number']);
    $address = trim($_POST['address']);
    $specialty = isset($_POST['specialty']) ? trim($_POST['specialty']) : null;
    $experience_years = isset($_POST['experience_years']) ? (int)$_POST['experience_years'] : null;

    // Build the SQL query
    $sql = "INSERT INTO users (first_name, last_name, username, email, password, dob, gender, role, contact_number, address, specialty, experience_years) 
            VALUES (
                '$first_name',
                '$last_name',
                '$username',
                '$email',
                '$password',
                '$dob',
                '$gender',
                '$role',
                '$contact_number',
                '$address',
                " . ($specialty ? "'$specialty'" : "NULL") . ",
                " . ($experience_years !== null ? $experience_years : "NULL") . "
            )";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        echo "<script>
                alert('Registration successful. Please log in.');
                window.location.href = '../view/login.html';
              </script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}
?>
