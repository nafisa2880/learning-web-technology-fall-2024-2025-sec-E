<?php
session_start();

// Check if the session is set for user_id and role, and if the role is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo "Please log in to access this page.";
    echo "<br><a href='../view/login.html'>Login Here</a>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        /* Your existing styles for the admin dashboard */
    </style>
</head>
<body>
    <h1>Welcome to the Admin Dashboard, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
    <!-- Your admin dashboard content here -->
</body>
</html>
